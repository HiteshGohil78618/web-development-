import axios from 'axios';
import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';

function AddEmployee() {
	const [data, setData] = useState({
		name: '',
		email: '',
		mobile: '',
		gender: '',
		password: '',
		address: '',
		salary: '',
		highest_education: '',
		department: '',

		image: ''
	})
	const navigate = useNavigate()

	const handleSubmit = (event) => {
		event.preventDefault();
		const formdata = new FormData();
		formdata.append("name", data.name);
		formdata.append("email", data.email);
		formdata.append("mobile", data.mobile);
		formdata.append("gender", data.gender);
		formdata.append("password", data.password);
		formdata.append("address", data.address);
		formdata.append("salary", data.salary);
		formdata.append("highest_education", data.highest_education);
		formdata.append("department", data.department);
		formdata.append("image", data.image);
		axios.post('http://localhost:8081/create', formdata)
			.then(res => {
				navigate('/employee')
			})
			.catch(err => console.log(err));
	}
	return (
		<div className='d-flex flex-column align-items-center pt-4'>
			<h2>Add Employee</h2>
			<form class="row g-3 w-50" onSubmit={handleSubmit}>
				<div class="col-12">
					<label for="inputName" className="form-label">Name</label>
					<input type="text" className="form-control" id="inputName" placeholder='Enter Name' autoComplete='off'
						onChange={e => setData({ ...data, name: e.target.value })} />
				</div>
				<div class="col-12">
					<label for="inputEmail" className="form-label">Email</label>
					<input type="email" className="form-control" id="inputEmail" placeholder='Enter Email' autoComplete='off'
						onChange={e => setData({ ...data, email: e.target.value })} />
				</div>
				<div class="col-12">
					<label for="inputmobile" className="form-label">mobile</label>
					<input type="text" className="form-control" id="inputmobile" placeholder='Enter Mobile' autoComplete='off'
						onChange={e => setData({ ...data, mobile : e.target.value })} />
				</div>
				<div class="col-12">
					<label for="inputgender" className="form-label">Gender</label>
					<select type="text" className="selct_dept form-control" id="inputdepartment " placeholder="Enter gender" autoComplete='off'
						onChange={e => setData({ ...data, gender: e.target.value })}>
						<option className="opt_dept" disabled selected hidden>Choose gender</option>
						<option className="opt_dept" value="Male">Male</option>
						<option className="opt_dept" value="Female">Female</option>

					</select>
				</div>
				<div class="col-12">
					<label for="inputPassword4" className="form-label">Password</label>
					<input type="password" className="form-control" id="inputPassword4" placeholder='Enter Password'
						onChange={e => setData({ ...data, password: e.target.value })} />
				</div>
				<div class="col-12">
					<label for="inputSalary" className="form-label">Salary</label>
					<input type="text" className="form-control" id="inputSalary" placeholder="Enter Salary" autoComplete='off'
						onChange={e => setData({ ...data, salary: e.target.value })} />
				</div>
				<div class="col-12">
					<label for="inputdepartment" className="form-label">Education</label>
					<select type="text" className="selct_dept form-control" id="inputdepartment " placeholder="Enter Education" autoComplete='off'
						onChange={e => setData({ ...data, highest_education: e.target.value })}>
						<option className="opt_dept" disabled selected hidden>Choose Education</option>
						<option className="opt_dept" value="BCA">BCA</option>
						<option className="opt_dept" value="MCA">MCA</option>
						<option className="opt_dept" value="b.tech">b.tech</option>
						<option className="opt_dept" value="m.tech">m.tech</option>
					 </select>
				</div>
				<div class="col-12">
					<label for="inputdepartment" className="form-label">department</label>
					<select type="text" className="selct_dept form-control" id="inputdepartment " placeholder="Enter department" autoComplete='off'
						onChange={e => setData({ ...data, department: e.target.value })}>
						<option className="opt_dept" disabled selected hidden>Choose Department</option>
						<option className="opt_dept" value="Front-End Developer">Front-End Development</option>
						<option className="opt_dept" value="Back-End Developer">Back-End Development</option>
						<option className="opt_dept" value="Project Management">Project Management</option>
						<option className="opt_dept" value="UI/UX Research">UI/UX Research</option>
						<option className="opt_dept" value="Sales and Marketing">Sales and Marketing</option>
						<option className="opt_dept" value="Finance and Accounting">Finance and Accounting</option>
                    </select>
				</div>
				<div class="col-12">
					<label for="inputAddress" className="form-label">Address</label>
					<input type="text" className="form-control" id="inputAddress" placeholder="1234 Main St" autoComplete='off'
						onChange={e => setData({ ...data, address: e.target.value })} />
				</div>
				<div class="col-12 mb-3">
					<label className="form-label" for="inputGroupFile01">Select Image</label>
					<input type="file" className="form-control" id="inputGroupFile01"
						onChange={e => setData({ ...data, image: e.target.files[0] })} />
				</div>
				<div class="col-12">
					<button type="submit" className="btnadn btn-primary">Create</button>

				</div>
			</form>
		</div>

	)
}

export default AddEmployee