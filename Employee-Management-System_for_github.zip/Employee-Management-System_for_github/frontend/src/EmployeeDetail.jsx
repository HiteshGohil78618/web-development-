import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import './style.css'

function EmployeeDetail() {
    const {id} = useParams();
    const navigate = useNavigate()
    const [employee, setEmployee] = useState([])
    useEffect(()=> {
        axios.get('http://localhost:8081/get/'+id)
        .then(res => setEmployee(res.data.Result[0]))
        .catch(err => console.log(err));
    })
    const handleLogout = () => {
		axios.get('http://localhost:8081/logout')
		.then(res => {
			navigate('/start')
		}).catch(err => console.log(err));
	}
  return (
    
    <div class='emp_bg'>
        <center><h1  className='for_center btnemp  justify-content-center'>Employee Profile</h1>
        <h1 className='btnadn '>Welcome : {employee.name}
        <p className="emp_det">Thank you for choosing to be a part of our company. Your talent and dedication are greatly appreciated, and we look forward to achieving success together as a team.</p>
        </h1></center>
        <div className='pro_seting'>
            <img src={`http://localhost:8081/images/`+employee.image} alt="" className='empImg'/>
            <div className=''>
                <h5>Name:<span className="emp_det"> {employee.name}</span></h5>
                <h5>Email: <span className="emp_det">{employee.email}</span></h5>
                <h5>Salary:<span className="emp_det"> {employee.salary}</span></h5>
                <h5>Address:<span className="emp_det"> {employee.address}</span></h5>
                <h5>Department:<span className="emp_det"> {employee.department}</span></h5>
            </div>
            <div>
            
               
                <button className='btndl btn-danger' onClick={handleLogout}>Logout</button>
            </div>
        </div>
    </div>
  )
}

export default EmployeeDetail