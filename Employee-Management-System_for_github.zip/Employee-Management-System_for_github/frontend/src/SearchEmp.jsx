import axios from 'axios'
import React, { useEffect, useState } from 'react'

import './style.css'

function SearchEmp() {
  const [data, setData] = useState([])
  const [search,setsearch]=useState("")
  useEffect(() => {
    axios.get('http://localhost:8081/getEmployee')
      .then(res => {
        if (res.data.Status === "Success") {
          
          setData(res.data.Result);
        } else {
          alert("Error")
        }
      })
      .catch(err => console.log(err));
  }, [])


 

  return (
    <div className='px-5 py-3'>
      <h1  className='btnadn btn-success'>Search Employee</h1>
      <input name="department" id='department'  class="selct_dept form-control mt-4" placeholder='search Employee'
					 onChange={e => setsearch(e.target.value)}/>
      <div className='d-flex justify-content-center mt-2'>
        <h3>Employee List</h3>
      </div><hr></hr>
      <div className='mt-3'>
        <table className='table table-striped'>
          <thead>
            <tr>
              <th>Name</th>
              <th>Image</th>
              <th>Email</th>
              <th>mobile</th>
              <th>Gender</th>
              <th>Address</th>
              <th>Salary</th>
              <th>Education</th>
              <th>Department</th>
              {/* <th>Action</th> */}
            </tr>
          </thead>
          <tbody>
            {data.filter((employee)=>{
              if(search===""){
                return employee
              }
              else if(employee.name.toLowerCase().includes(search.toLowerCase())){
                return employee
              }
            })
            .map((employee, index) => {
              return <tr key={index}>
                <td>{employee.name}</td>
                <td>{
                  <img src={'http://localhost:8081/images/' + employee.image} alt='' className='employee_image' />
                }</td>
                <td>{employee.email}</td>
                <td>{employee.mobile}</td>
                <td>{employee.gender}</td>
                <td>{employee.address}</td>
                <td>${employee.salary}</td>
                <td>{employee.highest_education}</td>
                <td>{employee.department}</td>
                {/* <td>
                  <Link to={'/employeeEdit/' + employee.id} className='btnemp btn-primary btn-sm me-2'>edit</Link>
                  <button onClick={e => handleDelete(employee.id)} className='btndl btn-sm btn-danger'>delete</button>
                </td> */}
              </tr>
            })}
          </tbody>
        </table>
      </div>
    </div>
  )

}


export default SearchEmp