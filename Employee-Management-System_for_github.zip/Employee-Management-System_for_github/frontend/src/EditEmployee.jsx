import React, { useEffect, useState } from 'react'
import axios from 'axios'
import { useNavigate, useParams } from 'react-router-dom';


function EditEmployee() {
    const [data, setData] = useState({
        name: '',
		email: '',
		mobile: '',
		gender: '',
		address: '',
		salary: '',
		highest_education: '',
		
    })

	const navigate = useNavigate()

    const {id}= useParams();

    useEffect(()=>{
       
        axios.get('http://localhost:8081/get/'+id)
        .then(res =>{
			setData({...data, name: res.data.Result[0].name, 
				email: res.data.Result[0].email,
				mobile: res.data.Result[0].mobile,
				gender: res.data.Result[0].gender,
				address: res.data.Result[0].address,
				salary: res.data.Result[0].salary,
				highest_education: res.data.Result[0].highest_education,
				department: res.data.Result[0].department,
				 })
		})
        .catch(err => console.log(err));
    }, [])
	
	const handleSubmit = (event) => {
		event.preventDefault();
		axios.put('http://localhost:8081/update/'+id, data)
			.then(res => {
				if(res.data.Status === "success"){
					navigate('/employee')
				}
				
			})
			.catch(err => console.log(err));
	}

    return (

        <div className='d-flex flex-column align-items-center pt-4'>
            <h2>Update Employee</h2>
           <form className="row g-3 w-50" onSubmit={handleSubmit}>
            <div className="col-12">
					<label for="inputName" className="form-label">Name</label>
					<input type="text" className="form-control" id="inputName" placeholder='Enter Name' autoComplete='off'
						onChange={e => setData({ ...data, name: e.target.value })} value={data.name}/>
				</div>
                <div class="col-12">
					<label for="inputEmail" className="form-label">Email</label>
					<input type="email" className="form-control" id="inputEmail" placeholder='Enter Email' autoComplete='off'
						onChange={e => setData({ ...data, email: e.target.value })} value={data.email}/>
				</div>
				<div class="col-12">
					<label for="inputmobile" className="form-label">mobile</label>
					<input type="text" className="form-control" id="inputmobile" placeholder='Enter Mobile' autoComplete='off'
						onChange={e => setData({ ...data, mobile : e.target.value })} value={data.mobile} />
				</div>
				<div class="col-12">
					<label for="inputgender" className="form-label">Gender</label>
					<select type="text" className="selct_dept form-control" id="inputdepartment " placeholder="Enter gender" autoComplete='off'
						onChange={e => setData({ ...data, gender: e.target.value })} value={data.gender} >
						<option className="opt_dept" disabled selected hidden>Choose gender</option>
						<option className="opt_dept" value="Male">Male</option>
						<option className="opt_dept" value="Female">Female</option>

					</select>
				</div>
                 <div class="col-12">
					<label for="inputSalary" className="form-label">Salary</label>
					<input type="text" className="form-control" id="inputSalary" placeholder="Enter Salary" autoComplete='off'
						onChange={e => setData({ ...data, salary: e.target.value })} value={data.salary}/>
				</div>

				<div class="col-12">
					<label for="inputdepartment" className="form-label">Education</label>
					<select type="text" className="selct_dept form-control" id="inputdepartment " placeholder="Enter Education" autoComplete='off'
						onChange={e => setData({ ...data, highest_education: e.target.value })} value={data.highest_education}>
						<option className="opt_dept" disabled selected hidden>Choose Education</option>
						<option className="opt_dept" value="BCA">BCA</option>
						<option className="opt_dept" value="MCA">MCA</option>
						<option className="opt_dept" value="b.tech">b.tech</option>
						<option className="opt_dept" value="m.tech">m.tech</option>
					 </select>
				</div>
				<div class="col-12">
					<label for="inputdepartment" className="form-label">department</label>
					<select type="text" className="selct_dept form-control" id="inputdepartment " placeholder="Enter department" autoComplete='off'
						onChange={e => setData({ ...data, department: e.target.value })} value={data.department}>
						<option className="opt_dept" disabled selected hidden>Choose Department</option>
						<option className="opt_dept" value="Front-End Developer">Front-End Development</option>
						<option className="opt_dept" value="Back-End Developer">Back-End Development</option>
						<option className="opt_dept" value="Project Management">Project Management</option>
						<option className="opt_dept" value="UI/UX Research">UI/UX Research</option>
						<option className="opt_dept" value="Sales and Marketing">Sales and Marketing</option>
						<option className="opt_dept" value="Finance and Accounting">Finance and Accounting</option>
                    </select>
				</div>
                <div class="col-12">
					<label for="inputAddress" className="form-label">Address</label>
					<input type="text" className="form-control" id="inputAddress" placeholder="1234 Main St" autoComplete='off'
						onChange={e => setData({ ...data, address: e.target.value })} value={data.address} />
				</div>
				
                <div class="col-12">
					<button type="submit" className="btnadn btn-primary">Update</button>
					
				</div>
            </form>
        </div>
    )

}


export default EditEmployee