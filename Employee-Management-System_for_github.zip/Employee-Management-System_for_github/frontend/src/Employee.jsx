import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import './style.css'

function Employee() {
  const [data, setData] = useState([])

  useEffect(() => {
    axios.get('http://localhost:8081/getEmployee')
      .then(res => {
        if (res.data.Status === "Success") {
          
          setData(res.data.Result);
        } else {
          alert("Error")
        }
      })
      .catch(err => console.log(err));
  }, [])


  const handleDelete = (id) => {
    axios.delete('http://localhost:8081/delete/' + id)
     .then(res =>{
      if(res.data.Status === "Success"){
        window.location.reload(true);
        alert("Record Deleted");
      }else{
        alert("Error")
      }
     })
     .catch(err => console.log(err));
  }

  return (
    <div className='px-1 py-1 '>
      <div className='d-flex justify-content-center mt-1'>
        <h3>Employee List</h3>
      </div>
      <Link to="/create" className='btnadn btn-success'>Add Employee</Link><hr></hr>
      <div className='mt-1 px-11'>
        <table className='table table-striped'>
          <thead >
            <tr>
              <th>Name</th>
              <th>Image</th>
              <th>Email</th>
              <th>mobile</th>
              <th>Gender</th>
              <th>Address</th>
              <th>Salary</th>
              <th>Education</th>
              <th>Department</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {data.map((employee, index) => {
              return <tr key={index}>
                <td>{employee.name}</td>
                <td>{
                  <img src={'http://localhost:8081/images/' + employee.image} alt='' className='employee_image' />
                }</td>
                <td>{employee.email}</td>
                <td>{employee.mobile}</td>
                <td>{employee.gender}</td>
                <td>{employee.address}</td>
                <td>${employee.salary}</td>
                <td>{employee.highest_education}</td>
                <td>{employee.department}</td>
                <td>
                  <Link to={'/employeeEdit/' + employee.id} className='btnempadd btn-primary btn-sm me-2'>Edit</Link>
                  <button onClick={e => handleDelete(employee.id)} className='btndladd btn-sm btn-danger'>Delete</button>
                </td>
              </tr>
            })}
          </tbody>
        </table>
      </div>
    </div>
  )

}


export default Employee