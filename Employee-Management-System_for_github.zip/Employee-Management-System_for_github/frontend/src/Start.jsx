import React from 'react'
import { useNavigate } from 'react-router-dom'
import './style.css'
function Start() {
    const navigate = useNavigate()
  return (
    <div className='forbg d-flex justify-content-center align-items-center vh-100 loginPage'>
            <div className='selection_div  rounded  border loginForm text-center '>
                <h2>Login As</h2><hr></hr>
                <div className='selection_div1 d-flex justify-content-between mt-5'>
                  <img src="img\Login-page-selection-character1.png" class="login_selection_avetar" alt="" />
                  <div class="container1">
                    <button className='btnemp ' onClick={e => navigate('/employeeLogin')}>Employee</button>
                    <button className='btnadn ' onClick={e => navigate('/login')}>Admin</button>
                    </div>
                </div>
            </div>
        </div>
  )
}

export default Start