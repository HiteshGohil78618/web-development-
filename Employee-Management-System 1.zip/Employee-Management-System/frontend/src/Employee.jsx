import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'

function Employee() {
  const [data, setData] = useState([])

  useEffect(() => {
    axios.get('http://localhost:8081/getEmployees')
      .then(res => {
        if (res.data.Status === "success") {
          console.log(res.data.Result)
          setData(res.data.Result);
        } else {
          alert("Error")
        }
      })
      .catch(err => console.log(err));
  }, [])

  return (
    <div className='px-5 py-3'>
      <div className='d-flex justify-content-center mt-2'>
        <h3>Employee List</h3>
      </div>
      <Link to="/create" className='btn btn-success'>Add Employee</Link>
      <table >
        <thead>
          <tr>
            <th>Name</th>
            <th>Image</th>
            <th>Email</th>
            <th>Address</th>
            <th>Salary</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {data.map((Employee, index) => {
           return <tr key={index}>
              <td>{Employee.name}</td>
              <td>{}</td>
              <td>{Employee.email}</td>
              <td>{Employee.address}</td>
              <td>{Employee.salary}</td>
              <td>
                <button>edit</button>
                <button>delete</button>
              </td>
            </tr>
          })}
        </tbody>
      </table>
    </div>
  )

}


export default Employee